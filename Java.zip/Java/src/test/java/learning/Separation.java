package learning;
import java.util.*;
public class Separation {
       public String numbers="";
       public String alphabets="";
       public String splcharacters="";
       // System.out.println(string.charAt(0));
       // System.out.println(n);
    public void separate1(String string) {
        int n=string.length();
        for (int i = 0; i < n; i++) {
            if (Character.isDigit(string.charAt(i))) {
                numbers = numbers + string.charAt(i);
            } else if (Character.isAlphabetic(string.charAt(i))) {
                alphabets = alphabets + string.charAt(i);
            } else {
                splcharacters = splcharacters + string.charAt(i);
            }
        }
        System.out.println("Alphabets are " + alphabets);
        System.out.println("Numbers are " + numbers);
        System.out.println("Special characters are " + splcharacters);
    }
}
