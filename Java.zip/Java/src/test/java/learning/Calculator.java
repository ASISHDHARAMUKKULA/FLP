package learning;

public class Calculator {

        public void addition ( int operand1, int operand2){

        System.out.println("Addition is " + (operand1 + operand2));
    }
        public void subtraction ( int operand1, int operand2){

        System.out.println("Subtraction is " + (operand1 - operand2));
    }
        public void multiplication ( int operand1, int operand2)
        {
            System.out.println("Multiplication is " + (operand1 * operand2));
        }
        public void division ( int operand1, int operand2){
            int result=0;
            try {
                result = operand1 / operand2;
            }catch (ArithmeticException e){
                System.out.println("Exception occured for the inputs "+operand1+","+operand2);
                e.printStackTrace();
            }
            finally {
                System.out.println("This is finally block");
            }
        System.out.println("Division is " + result);
    }


}
