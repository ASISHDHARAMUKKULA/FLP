package learning;

public class Akhi {
    public static void main(String[] args) {
        FirstProgram akhi=new FirstProgram(" akhi ");
        akhi.height=5;
        akhi.height();
        akhi.weight(50);
        akhi.gender="Female";
        akhi.gender();
        FirstProgram sri=new FirstProgram(" sri ");
        sri.height=6;
        sri.height();
        akhi.height();
    }
}
