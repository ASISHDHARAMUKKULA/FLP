package learning;
import java.util.*;
import java.io.*;
public class Operation {
    static int operand1;
    static int operand2;
    public static void main(String[] args) {
        FileReader reader= null;
        try {
            reader = new FileReader("TestData.properties");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        Properties p=new Properties();
        try {
            p.load(reader);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(p.getProperty("operand1"));
        System.out.println(p.getProperty("operand2"));
        operand1=Integer.parseInt(p.getProperty("operand1"));
        operand2=Integer.parseInt(p.getProperty("operand2"));

        Calculator o=new Calculator();
        o.addition(operand1,operand2);
        o.division(operand1,operand2);
    }
}
