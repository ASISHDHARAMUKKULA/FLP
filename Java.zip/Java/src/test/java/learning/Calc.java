package learning;
import java.util.*;

public class Calc {
    public static void main(String[] args) {
        Calculator a=new Calculator();
        Scanner sc=new Scanner(System.in);
        int i=sc.nextInt();
        switch(i){
            case 1:a.addition(5,6);break;
            case 2:a.subtraction(6,2);break;
            case 3:a.multiplication(4,8);break;
            case 4:a.division(6,2);break;
            default:
                System.out.printf("Enter valid operation");

        }
    }
}
