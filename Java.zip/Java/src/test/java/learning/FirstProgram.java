package learning;

public class FirstProgram {
    FirstProgram(String s){
        System.out.printf("Constructor "+s);
    }
    public int weight;
    public int height;
    public String gender;
    public  void talk(){
        System.out.println("Hello");

    }
    public  void weight(int weight){
        System.out.println("Weight is "+weight);

    }
    public  void height(){
        System.out.println("Height is "+height);

    }
    public  void gender(){
        System.out.println("Gender is "+gender);

    }
}
