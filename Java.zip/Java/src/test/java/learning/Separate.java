package learning;

public class Separate {
    public static void main(String[] args) {
        Separation separate=new Separation();
        separate.separate1("12#$AV%^2376");
    }
}
