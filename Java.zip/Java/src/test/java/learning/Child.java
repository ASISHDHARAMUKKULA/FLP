package learning;

public class Child extends Parent{
Child(int b){
    super(b);
    super.bike();
    System.out.println("Child constructor: "+b);
}
    public void bike() {
    System.out.println("Child Bike");
}
    public void bike(int petrolinlitres){
        System.out.println("Overloading bike "+petrolinlitres);
    }

}
