package learning;

public class Parent {
    int pen=20;
    Parent(int a){
        System.out.println("Parent Constructor: "+a);
    }
    public void bike(){
        System.out.println("Parent Bike");
    }
    public void mobile(){
        System.out.println("Parent Mobile");
    }
}
