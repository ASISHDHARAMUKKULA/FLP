package learning;

public class InheritanceTest {
    public static void main(String[] args) {
     Child child=new Child(30);
     child.bike();
     child.mobile();
     child.bike(50);
        System.out.println(child.pen);
    }
}
