package Day3;

public class InterfaceChild2 implements InterfaceExample {
    @Override
    public void test1() {
        System.out.println("Child2 test1");
    }

    @Override
    public void test2() {
        System.out.println("Child2 test2");
    }
}
