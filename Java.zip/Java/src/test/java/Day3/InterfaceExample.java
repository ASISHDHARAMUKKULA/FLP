package Day3;

public interface InterfaceExample {
    public void test1();
    public void test2();
}
