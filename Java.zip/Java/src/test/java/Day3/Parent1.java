package Day3;

public class Parent1 {
    Parent1(){
        System.out.println("Parent Constructor");
    }
    Parent1(int operand1){
        System.out.println("Parent overloaded constructor");
    }
    public void property(){
        System.out.println("Parent property ");
    }
    public void car(){
        System.out.println("Parent car");
    }

}
