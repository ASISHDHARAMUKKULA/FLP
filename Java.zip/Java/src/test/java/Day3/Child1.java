package Day3;

public class Child1 extends Parent1 {
    int amount;
   public void property(){
       super.property();
       System.out.println("Child Property");
   }
   public void property(int amount){
       this.amount=amount;
       System.out.println("Overloading method in child "+amount);
   }
    }

