package Day3;

public interface InterfaceExample1 {
    public void method1();
    public void method2();

}
