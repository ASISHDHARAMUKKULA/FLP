package Day3;


public class AllConcepts {
    static int operand1=10;
    static int operand2=20;
    public static void main(String[] args) {
        Child1 child1 = new Child1();
        child1.property();
        child1.property(70000);
        child1.car();
        System.out.println("Operand1: "+operand1);
        System.out.println("Operand2: "+operand2);
    }

}
