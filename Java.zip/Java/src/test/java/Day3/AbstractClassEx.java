package Day3;

public abstract class AbstractClassEx {
    public void implemented(){
        System.out.println("Implemented method");
    }
    public abstract void unImplemented();

}
