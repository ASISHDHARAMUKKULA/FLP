package Day3;

public class AbstractTest1 {
    public static void main(String[] args) {
        AbstractExample abstractExample = new AbstractChild();
        abstractExample.username("Akhila");
        abstractExample.password("******");
        AbstractChild abstractChild=new AbstractChild();
        abstractChild.username("Sri valli");
        abstractChild.password("******");
    }
}
