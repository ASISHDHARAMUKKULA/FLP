package Day3;

public class InterfaceTest {
    public static void main(String[] args) {
       InterfaceExample interfaceExample=new InterfaceChild2();
       interfaceExample.test1();
       interfaceExample.test2();
    }
}
