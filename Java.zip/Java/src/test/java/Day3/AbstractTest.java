package Day3;

public class AbstractTest {
    public static void main(String[] args) {
        AbstractClassEx childforAbstract=new ChildforAbstract();
        childforAbstract.unImplemented();
        childforAbstract.implemented();
        AbstractClassEx child2=new Child2();
        child2.unImplemented();
    }
}
