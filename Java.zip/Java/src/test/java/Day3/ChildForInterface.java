package Day3;

public class ChildForInterface implements InterfaceExample {
    @Override
    public void test1() {
        System.out.println("test1");
    }

    @Override
    public void test2() {
        System.out.println("test2");
    }
}
