package Day3;

public class ChildInterface implements InterfaceExample1,InterfaceExample2 {
    @Override
    public void method1() {
        System.out.println("Interface method1 in child");
    }

    @Override
    public void method2() {
        System.out.println("Interface method2 in child");
    }

    @Override
    public void method3() {
        System.out.println("Interface method3 in Child");
    }

    @Override
    public void method4() {
        System.out.println("Interface method4 in Child");
    }
}
