package Day3;

public class Child2 extends AbstractClassEx {
    @Override
    public void unImplemented() {
        System.out.println("Child2 Implementation");
    }
}
