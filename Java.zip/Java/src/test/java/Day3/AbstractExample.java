package Day3;

public abstract class AbstractExample {
        public void username(String username){
        System.out.println("Username is: "+username);
    }
    public abstract void password(String password);
}
