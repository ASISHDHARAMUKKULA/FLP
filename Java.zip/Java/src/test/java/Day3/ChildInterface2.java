package Day3;

public class ChildInterface2 implements InterfaceExample1{
    @Override
    public void method1() {
        System.out.println("Interface method1 in child2");
    }

    @Override
    public void method2() {
        System.out.println("Interface method2 in child2");
    }
}
