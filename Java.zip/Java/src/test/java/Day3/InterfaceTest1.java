package Day3;

public class InterfaceTest1 {
    public static void main(String[] args) {
        InterfaceExample1 interfaceExample1=new ChildInterface();
        interfaceExample1.method1();
        interfaceExample1.method2();
        InterfaceExample1 interfaceExample11=new ChildInterface2();
        interfaceExample11.method1();
        interfaceExample11.method2();
        ChildInterface childInterface=new ChildInterface();
        childInterface.method1();
        childInterface.method2();
        childInterface.method3();
        childInterface.method4();
    }
}
