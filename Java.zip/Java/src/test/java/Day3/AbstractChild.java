package Day3;

public class AbstractChild extends AbstractExample{
    @Override
    public void password(String password) {
        System.out.println("Password is:"+password);
    }
}
