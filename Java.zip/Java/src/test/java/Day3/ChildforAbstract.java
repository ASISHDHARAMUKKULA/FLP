package Day3;

public class ChildforAbstract extends AbstractClassEx {
    @Override
    public void unImplemented() {
        System.out.println("Child1 Implementation");
    }
}
