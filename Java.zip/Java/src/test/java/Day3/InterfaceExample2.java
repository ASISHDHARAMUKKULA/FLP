package Day3;

public interface InterfaceExample2 {
    public void method3();
    public void method4();
}
